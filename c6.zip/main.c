/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n1;
    int n2;
    int soma;
    int sub;
    int divs;
    int mult;
    printf("Digite o primeiro numero: ");
    scanf("%d", &n1);
    printf("Digite o segundo numero: ");
    scanf("%d", &n2);
    soma = n1 + n2;
    sub = n1 - n2;
    divs = n1/n2;
    mult = n1 * n2;
    printf ("%d + %d = %d\n", n1,n2,soma);
    printf ("%d - %d = %d\n", n1,n2,sub);
    printf ("%d / %d = %d\n", n1,n2,divs);
    printf ("%d * %d = %d\n", n1,n2,mult);
    

    return 0;
}
