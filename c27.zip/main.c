/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float cels;
    float fire;
    
    printf("Digite a temperatura em celsius: ");
    scanf ("%f", &cels);
    
    fire = cels * 1.8 + 32;
    
    printf ("Sua temperatura em Fahrenheit e: %.2f", fire);

    return 0;
}
