/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float aula;
    float quant;
    float inss;
    float salario;
    float porcentagem;
    float bruto;
    printf("Valor da aula: ");
    scanf ("%f", &aula);
    printf ("Quantidade de aulas: ");
    scanf ("%f", &quant);
    printf ("Porcentagem de desconto INSS: ");
    scanf ("%f", &inss);
    
    bruto = aula*quant;
    porcentagem = (inss /100) * bruto;
    salario = bruto - porcentagem;
    
    printf ("Salario liquido: %.2f", salario);

    return 0;
}
