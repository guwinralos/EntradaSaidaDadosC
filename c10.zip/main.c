/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int b1;
    int b2;
    int h;
    int a;
    
    printf("BASE MAIOR: ");
    scanf ("%d", &b1);
    printf ("BASE MENOR: ");
    scanf ("%d", &b2);
    printf ("ALTURA: ");
    scanf ("%d", &h);
    
    a = h * (b1+b2)/2;
    
    printf ("AREA DO TRAPEZIO = %d", a);

    return 0;
}
