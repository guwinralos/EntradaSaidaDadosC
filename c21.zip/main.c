/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n1;
    int n2;
    int m;
    
    printf("NUMERO 1: ");
    scanf ("%d", &n1);
    printf ("NUMERO 2: ");
    scanf ("%d", &n2);
    
    m = (n1+ n2)/2;
    
    printf ("EXIBIR MEDIA ARITMETICA: %d", m);
    
    

    return 0;
}
