/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int l;
    int a;
    int p;
    
    printf("Digite o lado do quadrado");
    scanf ("%d", &l);
    
    p = l*4;
    a = l*l;
    
    printf ("Area = %d\n", a);
    printf ("Perimetro = %d", p);
    
    

    return 0;
}
